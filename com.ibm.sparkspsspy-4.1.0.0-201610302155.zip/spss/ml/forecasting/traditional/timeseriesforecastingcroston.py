#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, DirectorScorerWithDM, PMMLWriter
from spss.ml.param.hascilevel import HasCILevelParams
from spss.ml.param.hasscorecrostonparams import HasScoreParams, HasInitContainerKeyParams
from spss.ml.param.timeseriesforecastingcrostonparams import TimeSeriesForecastingCrostonParams, \
    HasTargets, \
    HasTargetList, \
    HasPredictionInterval


@inherit_doc
class TimeSeriesForecastingCroston(AFEstimator,
                                   TimeSeriesForecastingCrostonParams,
                                   HasScoreParams,
                                   HasPredictionInterval,
                                   HasTargetList,
                                   HasCILevelParams
                                   ):
    """
    TimeSeriesForecastingCroston and modified TimeSeriesForecastingCroston methods are used to model and forecast intermittent time series. Many time series, for example the demand series for spare parts, are intermittent time series. The demands for spare parts appear at random, with many time periods having no demand. The Croston's method gives a more explicit representation of the demand pattern by making separate estimates of demand size and inter-arrival interval of demands. This strategy greatly increases the accuracy of intermittent demand forecasts and stock control. Note that the Croston's method forecasts the average demand rate, not the point estimation at a particular time point. An intermittency test is also provided to identify whether the input time series is intermittent before applying the Croston's model.

    Example code:\n
    >>> from spss.ml.forecasting.params.temporal import Fit, ForecastEs
    >>> from spss.ml.forecasting.params.predictor import Predictor,ScorePredictor
    >>> from spss.ml.common.wrapper import LocalContainerManager, SPSSJavaWrapper
    >>> from spss.ml.forecasting.timeseriesdatapreparation import TimeSeriesDataPreparation
    >>> from spss.ml.forecasting.reversetimeseriesdatapreparation import ReverseTimeSeriesDataPreparation
    >>> from spss.ml.forecasting.traditional.timeseriesforecastingcroston import TimeSeriesForecastingCroston
    >>> tsdp = TimeSeriesDataPreparation().
    ...    setMetricFieldList(["Demand"]).
    ...    setDateTimeField("Date").
    ...    setEncodeSeriesID(True).
    ...    setInputTimeInterval("MONTH").
    ...    setOutTimeInterval("MONTH").
    ...    setQualityScoreThreshold(0.0).
    ...    setConstSeriesThreshold(0.0)
    >>>  tsdp_df = tsdp.transform(data)
    >>>  targetPredictorList = Predictor([["Demand"]])
    >>>  cm = LocalContainerManager()
    >>>  cm.exportContainers("Container", tsdp.containers)
    >>>  tsmc = TimeSeriesForecastingCroston(cm).
    ...    setForecastMethod("REGULAR").
    ...    setObjFunction("SSE").
    ...    setCILevel(0.95).
    ...    setTargetList([targetPredictorList]).
    ...    setInputContainerKeys(["Container"])
    >>>  tsmcModel = tsmc.fit(tsdp_df)
    >>>  sp = ScorePredictor()
    >>>  fit = Fit(outFit = True, outCI = True, outResidual = True)
    >>>  forecast = ForecastEs(outForecast = True, outCI = True)
    >>>  tsmcForecastDf = tsmcModel.setTargets(sp).
    ...    setFitSettings(fit).
    ...    setForecast(forecast).
    ...    setInputContainerKeys(["Container"]).
    ...    transform(tsdp_df)
    >>>  rtsdp = ReverseTimeSeriesDataPreparation(cm).
    ...    setDeriveFutureIndicatorField(True).
    ...    setInputContainerKeys(["Container", "ScoreOutput"])
    >>>  rtsdpDF = rtsdp.transform(tsmcForecastDf)
    """

    def __init__(self, manager):
        super(TimeSeriesForecastingCroston, self).__init__(manager,
                                                           'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingCroston')

    def _create_model(self, java_model):
        return TimeSeriesForecastingCrostonModel(None, dataModel=None, java_model=java_model,)


class TimeSeriesForecastingCrostonModel(DirectorScorerWithDM,
                                        HasScoreParams,
                                        HasPredictionInterval,
                                        HasTargets,
                                        HasCILevelParams,
                                        HasInitContainerKeyParams,
                                        PMMLWriter):
    """
    Model produced by :class:`TimeSeriesForecastingCroston`.

    TimeSeriesForecastingCroston exports two outputs:

    * PMML file, contains TimeSeriesForecasting model information.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `TimeSeriesForecasting Output Document <../../../../../../output-doc/TimeSeriesForecasting.html>`_.
    """

    def __init__(self, manager, dataModel=None, java_model=None):
        super(TimeSeriesForecastingCrostonModel, self).__init__(manager,
                                                                'com.ibm.spss.ml.forecasting.traditional.TimeSeriesForecastingCrostonModel',
                                                                java_model,
                                                                dataModel)
