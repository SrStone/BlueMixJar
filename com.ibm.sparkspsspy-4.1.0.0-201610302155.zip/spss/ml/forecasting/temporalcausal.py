#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, DirectorScorer
from spss.ml.param.temporalcausal import TemporalCausalParams
from spss.ml.param.temporalcausalmodel import TemporalCausalModelParams
from spss.ml.common.wrapper import DirectorUtility
from spss.ml.param.temporalcausalscenarioanalysis import TemporalCausalScenarioAnalysisParams
from spss.ml.param.temporalcausalsummary import TemporalCausalSummaryParams
from spss.ml.param.temporalcausalrootcauseanalysis import TemporalCausalRootCauseAnalysisParams
from spss.ml.param.temporalcausaloutlinerdetection import TemporalCausalOutlinerDetectionParams
from spss.ml.param.temporalcausalautoregressivemodel import TemporalCausalAutoRegressiveModelParams


@inherit_doc
class TemporalCausal(AFEstimator, TemporalCausalParams):
    """
    Temporal causal modeling (TCM) refers to a suite of methods that attempt to
    discover key temporal relationships in time series data by using a combination of Granger
    causality and regression algorithms for variable selection.

    Example code:

    >>> from spss.ml.forecasting.temporalcausal import TemporalCausal
    >>> tsdp = TimeSeriesDataPreparation().setDimFieldList(["Demension1", "Demension2"]).
    ...     setMetricFieldList(["m1", "m2", "m3", "m4"]).
    ...     setDateTimeField("date").
    ...     setEncodeSeriesID(True).
    ...     setInputTimeInterval("MONTH").
    ...     setOutTimeInterval("MONTH")
    >>> tsdpOutput = tsdp.transform(changedDF)
    >>> lcm = LocalContainerManager()
    >>> lcm.exportContainers("TSDP", tsdp.containers)
    >>> estimator = TemporalCausal(lcm).
    ...     setInputContainerKeys(["TSDP"]).
    ...     setTargetPredictorList([Predictor(
    ...     targetList = [["","",""]],
    ...     predictorCandidateList = [["","",""]])).
    ...     setMaxNumPredictor(MaxNumberOfPredictor(False, 4)).
    ...     setMaxLag(MaxLag("SETTING", 5)).
    ...     setTolerance(1e-6)
    >>> tcmModel = estimator.fit(tsdpOutput)
    >>> transformer = tcmModel.setDataEncoded(True).
    ...     setCILevel(0.95).
    ...     setOutTargetValues(False).
    ...     setTargets(FieldSettings(fieldNameList = FieldNameList(seriesIDList = [["da1","db1","m1"]]))).
    ...     setReestimate(False).
    ...     setForecast(Forecast(outForecast = True, forecastSpan = 5, outCI = True)).
    ...     setFit(Fit(outFit = True, outCI = True, outResidual = True))
    >>> predictions = transformer.transform(tsdpOutput)
    >>> rtsdp = ReverseTimeSeriesDataPreparation(lcm).
    ...     setInputContainerKeys(["TSDP"]).
    ...     setDeriveFutureIndicatorField(True)
    >>> rtsdpOutput = rtsdp.transform(predictions)
    >>> rtsdpOutput.show()
    """

    def __init__(self, manager=None):
        super(TemporalCausal, self).__init__(manager, 'com.ibm.spss.ml.forecasting.TemporalCausal')

    def _create_model(self, java_model):
        return TemporalCausalModel(None, java_model)


@inherit_doc
class TemporalCausalModel(DirectorScorer, TemporalCausalModelParams):
    """
    TCM Score provides scores for Temporal Causal Models (TCM). There are two types of scoring:
    (1) fit: in-sample forecasts for the historical values of the target series;
    (2) forecast: out-of-sample forecasts for the future values of the target series.

    TCM Score also supports the "re-estimate" feature that re-estimates the coefficients of the predictor
    series in the built models and re-computes post-estimation statistics while fixing the model form.
    If re-estimate and fit and/or forecast are selected, first run re-estimate, then run fit and/or forecast
    based on the built model with re-estimated coefficients.

    Model produced by :class:`TemporalCausal`

    TemporalCausal exports outputs:

    * JSON file, contains TemporalCausal model information.
    * XML file, contains multi series model.

    For details about outputs, refer to `TemporalCausal Output Document <../../../../../../output-doc/TemporalCausal.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(TemporalCausalModel, self).__init__(manager,
                                                  'com.ibm.spss.ml.forecasting.TemporalCausalModel',
                                                  java_model)


@inherit_doc
class TemporalCausalAutoRegressiveModel(DirectorScorer, TemporalCausalAutoRegressiveModelParams):
    """
    Autoregressive (AR) models are built to compute out-of-sample forecasts for predictor series
    that are not target series. These predictor forecasts are then be used to compute out-of-sample
    forecasts for the target series.

    Model produced by :class:`TemporalCausal`

    TemporalCausal exports outputs:

    * JSON file, contains TemporalCausal model information.
    * XML file, contains multi series model.

    For details about outputs, refer to
    `TemporalCausal Output Document <../../../../../../output-doc/TemporalCausal.html>`_.

    Example code:

    >>> from spss.ml.forecasting.temporalcausal import TemporalCausalAutoRegressiveModel
    >>> target = FieldSettingsAr(FieldNameList(
    ...     seriesIDList=[["da1", "db1", "m1"],
    ...         ["da1", "db2", "m2"],
    ...         ["da1", "db3", "m3"]]))
    >>> tcmAr = TemporalCausalAutoRegressiveModel(containManager).
    ...     setInputContainerKeys(["key"]).
    ...     setDataEncoded(True).
    ...     setOutTargetValues(True).
    ...     setTargets(target).
    ...     setForecast(ForecastAr(forecastSpan = 5))
    >>> scored = tcmAr.transform(df)
    >>> scored.show()
    """

    def __init__(self, manager, java_model=None):
        super(TemporalCausalAutoRegressiveModel, self).__init__(manager,
                                                                'com.ibm.spss.ml.forecasting.TemporalCausalAutoRegressiveModel',
                                                                java_model)


@inherit_doc
class TemporalCausalOutlinerDetection(DirectorUtility, TemporalCausalOutlinerDetectionParams):
    """
    One of the advantages of building TCM models is the ability to detect model-based outliers.
    Outlier detection refers to a capability to identify the time points in the target series with values
    that stray too far from their expected (fitted) values based on the TCM models.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.forecasting.params.temporal import TargetTimeSeries
    >>> from spss.ml.forecasting.temporalcausal import TemporalCausal,TemporalCausalOutlinerDetection
    >>> lcm = LocalContainerManager()
    >>> estimator = TemporalCausal(lcm).
    ...             setInputContainerKeys([tsdp.uid]).
    ...             setTargetPredictorList([Predictor(
    ...                                     targetList = [["", "", ""]],
    ...                                     predictorCandidateList = [["", "", ""]])]).
    ...             setMaxNumPredictor(MaxNumberOfPredictor(False, 4)).
    ...             setMaxLag(MaxLag("SETTING", 5))
    >>> estimator.fit(df)
    >>> tcmOd = TemporalCausalOutlinerDetection(df, lcm, sqlContext).
    ...         setInputContainerKeys([estimator.uid]).
    ...         setTargets(TargetTimeSeries([["da1", "db1", "m2"]])).
    ...         setThreshold(0.6).
    ...         setDataEncoded(True).run()
    >>> tcmOd.containerSeq()
    """

    def __init__(self, df, manager, sqlCtx):
        super(TemporalCausalOutlinerDetection, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.forecasting.TemporalCausalOutlinerDetection',
                                            df,
                                            manager._java_instance, sqlCtx._ssql_ctx)


@inherit_doc
class TemporalCausalRootCauseAnalysis(DirectorUtility, TemporalCausalRootCauseAnalysisParams):
    """
    The root cause analysis refers to a capability to explore the Granger causal graph in order to analyze
    the key/root values that resulted in the outlier in question.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.forecasting.params.temporal import OutlierDetection
    >>> from spss.ml.forecasting.temporalcausal import TemporalCausal,TemporalCausalRootCauseAnalysis
    >>> lcm = LocalContainerManager()
    >>> estimator = TemporalCausal(lcm).
    ...             setInputContainerKeys([tsdp.uid]).
    ...             setTargetPredictorList([Predictor(
    ...                                     targetList = [["", "", ""]],
    ...                                     predictorCandidateList = [["", "", ""]])]).
    ...             setMaxNumPredictor(MaxNumberOfPredictor(False, 4)).
    ...             setMaxLag(MaxLag("SETTING", 5))
    >>> estimator.fit(df)
    >>> tcmRca = TemporalCausalRootCauseAnalysis(df, lcm, sqlContext).
    ...          setInputContainerKeys([estimator.uid]).
    ...          setDataEncoded(True).
    ...          setTargets(["da1", "db1", "m2"]).
    ...          setStdOutlierTimePoints([1266192000, 1268006400]).
    ...          setSubstituedValuesMethod("FIRST_PREDICTED").
    ...          setCausalLevel(5).run()
    >>> tcmRca.containerSeq()
    """
    def __init__(self, df, manager, sqlCtx):
        super(TemporalCausalRootCauseAnalysis, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.forecasting.TemporalCausalRootCauseAnalysis',
                                            df,
                                            manager._java_instance, sqlCtx._ssql_ctx)


@inherit_doc
class TemporalCausalScenarioAnalysis(DirectorUtility, TemporalCausalScenarioAnalysisParams):
    """
    Scenario analysis refers to a capability of the TCM models to "play-out" the repercussions of
    artificially setting the value of a time series. A scenario is the set of forecasts that are
    performed by substituting the values of a root time series by a vector of substitute values.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.forecasting.params.temporal import TargetTimeSeries
    >>> from spss.ml.forecasting.temporalcausal import TemporalCausal,TemporalCausalScenarioAnalysis
    >>> lcm = LocalContainerManager()
    >>> estimator = TemporalCausal(lcm).
    ...             setInputContainerKeys([tsdp.uid]).
    ...             setTargetPredictorList([Predictor(
    ...                                     targetList = [["", "", ""]],
    ...                                     predictorCandidateList = [["", "", ""]])]).
    ...             setMaxNumPredictor(MaxNumberOfPredictor(False, 4)).
    ...             setMaxLag(MaxLag("SETTING", 5))
    >>> estimator.fit(df)
    >>> tcmSa = TemporalCausalScenarioAnalysis(df, lcm, sqlContext).
    ...         setInputContainerKeys([estimator.uid]).
    ...         setRootSeries(["da1", "db1", "m1"]).
    ...         setStdStartTime(1264896000).
    ...         setStdEndTime(1267920000).
    ...         setStdFurthestTime(1269734400).
    ...         setSubstitutedVals([1.2, 1.3, 1.4, 1.5, 1.6]).
    ...         setTargets(TargetTimeSeries([["da1", "db1", "m3"], ["da1", "db1", "m5"]])).
    ...         setDataEncoded(True).run()
    >>> tcmSa.containerSeq()
    """

    def __init__(self, df, manager, sqlCtx):
        super(TemporalCausalScenarioAnalysis, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.forecasting.TemporalCausalScenarioAnalysis',
                                            df,
                                            manager._java_instance, sqlCtx._ssql_ctx)


@inherit_doc
class TemporalCausalSummary(DirectorUtility, TemporalCausalSummaryParams):
    """
    TCM Summary selects Top N models based on one model quality measure. There are five model quality measures:
    Root Mean Squared Error (RMSE), Root Mean Squared Percentage Error (RMSPE),
    Bayesian Information Criterion (BIC), Akaike Information Criterion (AIC) and R squared (RSQUARE).
    Both N and the model quality measure can be set by the user.

    Example code:

    >>> from spss.ml.forecasting.temporalcausal import TemporalCausalSummary
    >>> tcmSum = TemporalCausalSummary(containManager, sqlContext).
    ...     setInputContainerKeys(["key"]).
    ...     setGoF("AIC").
    ...     setBestModelsSelectionMethod("N").
    ...     setValue(2).
    ...     run()
    >>> json = tcmSum.containerSeq().entryStringContent("modelSummary.json")
    """

    def __init__(self, manager, sqlCtx):
        super(TemporalCausalSummary, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.forecasting.TemporalCausalSummary',
                                            manager._java_instance, sqlCtx._ssql_ctx)
