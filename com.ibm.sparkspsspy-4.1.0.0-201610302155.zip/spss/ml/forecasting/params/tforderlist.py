#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#
from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import SPSSJavaWrapper


@inherit_doc
class TFOrderList(object):
    def __init__(self,
                 targetList,
                 predictorList,
                 nonSeasonal=None,
                 seasonal=None,
                 transType=None,
                 delay=0):

        self._targetList = SPSSJavaWrapper.scalaListList(targetList)
        self._predictorList = SPSSJavaWrapper.scalaListList(predictorList)
        self._nonSeasonal = SPSSJavaWrapper.scalaList(nonSeasonal)
        self._seasonal = SPSSJavaWrapper.scalaList(seasonal)
        self._transType = transType
        self._delay = delay

        self._java_object = self.value

    @property
    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.forecasting.params.TFOrderList',
                                             self._targetList,
                                             self._predictorList,
                                             self._nonSeasonal,
                                             self._seasonal,
                                             self._transType,
                                             self._delay)
