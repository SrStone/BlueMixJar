#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, IdentityScorer, StatXMLExportable
from spss.ml.param.smartreports import SmartReportsParams
from spss.ml.param.hastargetfield import HasTargetFieldParams


@inherit_doc
class SmartReports(AFEstimator, SmartReportsParams, HasTargetFieldParams):
    """
    SmartReports is a model-based exploratory algorithm.
    Given a data set with a target and a set of categorical predictors (factors), it attempts to discover the most relevant one-way and two-way tabular reports and to provide some valuable insights to business users.
    (Continuous predictors must be binned before SmartReports and then can be treated as categorical predictors or factors in SmartReports.)

    The analysis for each tabular report is based on a statistical model including a target and a categorical predictor for one-way tabular reports, or a target and two categorical predictors for two-way tabular reports.
    The statistical model depends on the target's measurement level (continuous or categorical). For a continuous target, a linear regression approach is used, while a logistic regression approach is used for a categorical target.

    Example code:

    >>> from spss.ml.smartreports import SmartReports
    >>> sr = SmartReports().
    ...     setTargetField("Educational_level").
    ...     setInputFieldList(["Sex_of_employee", "Minority_classification", "agecat"])
    >>> srModel = sr.fit(df)
    >>> statXML = srModel.statXML()
    """

    def __init__(self, manager=None):
        super(SmartReports, self).__init__(manager, 'com.ibm.spss.ml.SmartReports')

    def _create_model(self, java_model):
        return SmartReportsModel(None, java_model)


class SmartReportsModel(IdentityScorer, StatXMLExportable):
    """
    Model produced by :class:`SmartReports`.

    SmartReports exports outputs:

    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `SmartReports Output Document <../../../../../../output-doc/SmartReports.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(SmartReportsModel, self).__init__(manager, 'com.ibm.spss.ml.SmartReportsModel', java_model)
