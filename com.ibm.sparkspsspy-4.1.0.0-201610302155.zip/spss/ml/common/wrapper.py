#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

import copy
import uuid
from abc import ABCMeta

from pyspark.ml.wrapper import JavaEstimator, JavaModel, JavaTransformer, JavaWrapper
from pyspark.sql import DataFrame

from spss.ml.param.scorer import ScorerParams

import sys
if sys.version > '3':
    unicode = str


class PythonIterable(object):
    """
    Wrapper scala `List` (jvm instance) to python iterable.

    Notes: for scala `Seq`, must call toList function because it has different apply function.
    """

    def __init__(self, _java_iter_inst):
        self._java_iter_inst = _java_iter_inst
        self.__high = _java_iter_inst.size()

    def __getitem__(self, k):
        if k >= self.__high:
            raise StopIteration
        else:
            return self._java_iter_inst.apply(k)

    def list(self):
        li = []
        for v in self:
            li.append(v)
        return li


class SPSSJavaWrapper(JavaWrapper):
    @staticmethod
    def jvm():
        from pyspark.ml import wrapper
        return wrapper._jvm()

    @staticmethod
    def loadContainers(containerPath):
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").loadContainers(
            SPSSJavaWrapper.scalaSeq(containerPath))

    @staticmethod
    def loadContainer(containerPath):
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").loadContainers(containerPath)

    @staticmethod
    def getDataModel(dataFrame):
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").getDataModel(dataFrame._jdf)

    @staticmethod
    def scalaSome(string):
        return SPSSJavaWrapper._new_java_obj("scala.Some", string)

    @staticmethod
    def scalaNone():
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").getScalaNone()

    @staticmethod
    def scalaNull():
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").getScalaNull()

    @staticmethod
    def scalaNil():
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").getScalaNil()

    @staticmethod
    def scalaSeq(values):
        v = SPSSJavaWrapper._noneEmptyList(values)
        return SPSSJavaWrapper.jvm().PythonUtils.toSeq(v)

    @staticmethod
    def scalaList(values):
        v = SPSSJavaWrapper._noneEmptyList(values)
        return SPSSJavaWrapper.jvm().PythonUtils.toSeq(v).toList()

    @staticmethod
    def scalaListList(values):
        v = SPSSJavaWrapper._noneEmptyList(values)
        li = []
        for v in v:
            li.append(SPSSJavaWrapper.scalaList(v))
        return SPSSJavaWrapper.scalaList(li)

    @staticmethod
    def scalaOptionListList(values):
        if values is None:
            return SPSSJavaWrapper.scalaNone()
        else:
            return SPSSJavaWrapper.scalaSome(SPSSJavaWrapper.scalaListList(values))

    @staticmethod
    def scalaTuple2(values):
        return SPSSJavaWrapper._new_java_obj("scala.Tuple2", values[0], values[1])

    @staticmethod
    def _noneEmptyList(values):
        v = []
        if values is not None:
            v = values
        return v

    @staticmethod
    def mergeSeq(seq1, seq2):
        return SPSSJavaWrapper._new_java_obj("com.ibm.spss.utils.PythonUtils").mergeSeq(seq1, seq2)


class Containers(object):
    __metaclass__ = ABCMeta

    def addInputContainerKeys(self, keys):
        self._java_obj.addInputContainerKeys(keys)
        return self

    def setInputContainerKeys(self, keys):
        self._java_obj.setInputContainerKeys(SPSSJavaWrapper.scalaSeq(keys))
        return self


class OutputDataCapability(object):
    __metaclass__ = ABCMeta

    def outputData(self, sqlContext):
        # return self._java_obj.outputData()
        return DataFrame(self._java_obj.outputData().get(), sqlContext)


class ContainerCapability(object):
    __metaclass__ = ABCMeta

    def containerSeq(self):
        return ContainerSeq(self.containers())

    def containers(self):
        return self._java_obj.containers()


def _getScalaContainerManager(manager):
    ret = manager
    if isinstance(ret, ContainerManager):
        ret = manager._java_instance
    return ret


def _checkNoneContainerManager(manager):
    ret = manager
    if ret is None:
        ret = LocalContainerManager()
    return ret


class AFTransformer(JavaTransformer, Containers):
    __metaclass__ = ABCMeta

    def __init__(self, manager, class_name):
        super(AFTransformer, self).__init__()

        manager = _checkNoneContainerManager(manager)
        self._java_obj = self._new_java_obj(class_name,
                                            _getScalaContainerManager(manager),
                                            self.uid)
        self.manager = manager


class SpatioTemporalTransformer(AFTransformer):

    def __init__(self, manager, class_name):
        super(SpatioTemporalTransformer, self).__init__(manager, class_name)


class AFEstimator(JavaEstimator, Containers):
    __metaclass__ = ABCMeta

    def __init__(self, manager, class_name):
        super(AFEstimator, self).__init__()

        manager = _checkNoneContainerManager(manager)
        self._java_obj = self._new_java_obj(class_name,
                                            _getScalaContainerManager(manager),
                                            self.uid)
        self.manager = manager


class OutputDataCapabilitiesEstimator(AFEstimator, OutputDataCapability):
    __metaclass__ = ABCMeta

    def __init__(self, manager, class_name):
        super(OutputDataCapabilitiesEstimator, self).__init__(manager, class_name)


class _ResetUid(object):
    def __init__(self):
        super(_ResetUid, self).__init__()

    def _resetUid(self, newUid):
        """
        Changes the uid of this instance. This updates both
        the stored uid and the parent uid of params and param maps.
        :param newUid: new uid to use, which is converted to unicode
        :return: same instance, but with the uid and Param.parent values
                 updated, including within param maps
        """
        newUid = unicode(newUid)
        self.uid = newUid
        newDefaultParamMap = dict()
        newParamMap = dict()
        for param in self.params:
            newParam = copy.copy(param)
            newParam.parent = newUid
            if param in self._defaultParamMap:
                newDefaultParamMap[newParam] = self._defaultParamMap[param]
            if param in self._paramMap:
                newParamMap[newParam] = self._paramMap[param]
            param.parent = newUid
        self._defaultParamMap = newDefaultParamMap
        self._paramMap = newParamMap
        return self


class _UUID():
    def __init__(self):
        super(_UUID, self).__init__()

    @classmethod
    def _uuid(cls):
        return cls.__name__ + "_" + uuid.uuid4().hex[12:]


class PMMLExportable(object):
    def __init__(self):
        super(self, PMMLExportable).__init__()

    def toPMML(self):
        """
        Extract PMML to string.
        """
        return self._java_obj.toPMML()


class StatXMLExportable():
    def __init__(self):
        super(self, PMMLExportable).__init__()

    def statXML(self):
        """
        Extract StatXML to string.
        """
        return self._java_obj.statXML()


class StatJSONExportable():
    def __init__(self):
        super(self, PMMLExportable).__init__()

    def statJSON(self):
        """
        Extract JSON to string.
        """
        return self._java_obj.statJSON()


class PMMLWriter():
    """
    Export model(s) to the PMML format.
    """

    def __init__(self):
        super(self, PMMLWriter).__init__()

    def writePMML(self, localPath):
        """
        Export the model(s) to a local directory in PMML format
        """
        return self._java_obj.writePMML(localPath)


class Scorer(JavaModel, ScorerParams, PMMLExportable, StatXMLExportable, ContainerCapability, Containers, _ResetUid, _UUID):
    __metaclass__ = ABCMeta

    def __init__(self, manager, class_name, java_model=None, pmmlString=None):
        if java_model is None:
            a_java_model = None
            if manager is None:
                a_java_model = self._new_java_obj(class_name, pmmlString)
            else:
                manager = _checkNoneContainerManager(manager)
                a_java_model = self._new_java_obj(class_name,
                                                  _getScalaContainerManager(manager),
                                                  self._uuid())
            super(Scorer, self).__init__(a_java_model)
        else:
            super(Scorer, self).__init__(java_model)

        self._resetUid(self.uid)


class DirectorScorer(JavaModel, ContainerCapability, Containers, _ResetUid, _UUID):
    __metaclass__ = ABCMeta

    def __init__(self, manager, class_name, java_model=None):
        if java_model is None:
            manager = _checkNoneContainerManager(manager)
            a_java_model = self._new_java_obj(class_name,
                                              _getScalaContainerManager(manager),
                                              self._uuid())
            super(DirectorScorer, self).__init__(a_java_model)
        else:
            super(DirectorScorer, self).__init__(java_model)
        self._resetUid(self.uid)


class DirectorScorerWithDM(JavaModel, ContainerCapability, Containers, _ResetUid, _UUID):
    __metaclass__ = ABCMeta
    # only used for TimeSeriesForecastingCrostonModel
    def __init__(self, manager, class_name, java_model=None, datamodel=None):
        if java_model is None:
            manager = _checkNoneContainerManager(manager)
            a_java_model = self._new_java_obj(class_name,
                                              datamodel,
                                              None,
                                              _getScalaContainerManager(manager),
                                              self._uuid())
            super(DirectorScorerWithDM, self).__init__(a_java_model)
        else:
            super(DirectorScorerWithDM, self).__init__(java_model)
        self._resetUid(self.uid)


class AFUtility(JavaWrapper, ContainerCapability, Containers):
    __metaclass__ = ABCMeta

    def __init__(self):
        super(AFUtility, self).__init__()

    def run(self):
        self._transfer_params_to_java()
        self._java_obj.run()
        return self

    def outputData(self):
        return self._java_obj.outputData()

    def outputDataModel(self):
        return self._java_obj.outputDataModel().get().toXmlString()


class DirectorUtility(JavaWrapper, ContainerCapability, Containers):
    __metaclass__ = ABCMeta

    def __init__(self):
        super(DirectorUtility, self).__init__()

    def run(self):
        self._transfer_params_to_java()
        self._java_obj.run()
        return self


class IdentityScorer(JavaModel, ContainerCapability, Containers, _UUID):
    def __init__(self, manager, class_name, java_model=None):
        if java_model is None:
            manager = _checkNoneContainerManager(manager)
            a_java_model = self._new_java_obj(class_name,
                                              _getScalaContainerManager(manager),
                                              self._uuid())
            super(IdentityScorer, self).__init__(a_java_model)
        else:
            super(IdentityScorer, self).__init__(java_model)


class ContainerManager(object):
    """
    Container Manager wrapper for python.
    """

    def __init__(self, container_class):
        self._java_instance = SPSSJavaWrapper._new_java_obj(container_class)

    def exportContainers(self, key, containers):
        return self._java_instance.exportContainers(key, containers)

    def importContainers(self, key):
        return self._java_instance.importContainers(key)

    def importContainerSeq(self, key):
        c = self.importContainers(key)
        isEmpty = True
        cons = []
        if c.isDefined():
            cons = c.get()
            isEmpty = False
        return ContainerSeq(cons, isEmpty)

    def discardContainers(self, key):
        return self._java_instance.discardContainers(key)

    def entries(self):
        return self._java_instance.entries()


class LocalContainerManager(ContainerManager):
    """
    Local Container Manager wrapper for python.

    Can be instanced as other container manager when pass container java class
    """

    def __init__(self):
        super(LocalContainerManager, self).__init__("com.ibm.spss.ml.common.LocalContainerManager")


class ContainerSeq(object):
    def __init__(self, containers, isEmpty=False):
        self._containers = []
        if not isEmpty:
            self._containers = PythonIterable(containers)

    def entriesNames(self):
        names = []
        for container in self._containers:
            it = PythonIterable(container.containerEntriesNames().toList())
            names.append(list(it))
        return names

    def entryStringContent(self, entryName):
        strContent = ""
        for container in self._containers:
            if entryName in PythonIterable(container.containerEntriesNames().toList()):
                strContent = container.containerEntry(entryName).get().stringContent()
                break
        return strContent

    def containers(self):
        containers = []
        for con in self._containers:
            containers.append(Container(con))
        return containers


class Container(object):
    def __init__(self, java_instance):
        self._java_instance = java_instance

    def containerEntry(self, name):
        return ContainerEntry(self._java_instance.containerEntry(name).get())

    def containerEntriesNames(self):
        return list(PythonIterable(self._java_instance.containerEntriesNames().toList()))

    def containerMeta(self):
        return ContainerMeta(self._java_instance.containerMeta)


class ContainerMeta(object):
    def __init__(self, java_instance):
        self._java_instance = java_instance

    def props(self):
        return self._java_instance.props()


class ContainerEntry(object):
    def __init__(self, java_instance):
        self._java_instance = java_instance

    def stringContent(self):
        return self._java_instance.stringContent()