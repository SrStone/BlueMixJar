#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from spss.ml.common.wrapper import SPSSJavaWrapper


class Event(object):
    def __init__(self, eventType, minState, maxState):
        self.eventType = SPSSJavaWrapper.scalaList(eventType)
        self.minState = SPSSJavaWrapper.scalaList(minState)
        self.maxState = SPSSJavaWrapper.scalaList(maxState)

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.frequentpatternmining.params.Event', self.eventType,
                                             self.minState, self.maxState)
