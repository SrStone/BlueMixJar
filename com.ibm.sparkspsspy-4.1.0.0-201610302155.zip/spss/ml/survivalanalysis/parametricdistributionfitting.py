#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.parametricdistributionfitting import ParametricDistributionFittingParams
from spss.ml.param.hasgroupfields import HasGroupFieldsParams
from spss.ml.param.hasstatusfield import HasStatusFieldParams
from spss.ml.param.hassurvivaltimefield import HasSurvivalTimeFieldParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hasensembleparams import HasEnsembleParamsParams


@inherit_doc
class ParametricDistributionFitting(AFEstimator,
                                    ParametricDistributionFittingParams,
                                    HasSurvivalTimeFieldParams,
                                    HasGroupFieldsParams,
                                    HasStatusFieldParams):
    """
    Survival analysis analyzes data where the outcome variable is the time until the
    occurrence of an event of interest.The distribution of the event times is typically
    described by a survival function.

    Parametric Distribution Fitting (PDF) provides an estimate of the survival function
    by comparing the functions for several known distributions (exponential, Weibull,
    log-normal, and log-logistic) to determine which, if any, describes the data best.
    In addition, the distributions for two or more groups of cases can be compared.

    Example code:

    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> from spss.ml.survivalanalysis.params.definedstatus import DefinedStatus, StatusItem, Points
    >>> from spss.ml.survivalanalysis.parametricdistributionfitting import ParametricDistributionFitting, ParametricDistributionFittingModel
    >>> pdf = ParametricDistributionFitting().
    ...       setBeginField("begintime").
    ...       setEndField("endtime").
    ...       setStatusField("status").
    ...       setFreqField("frequency").
    ...       setDefinedStatus(
    ...       DefinedStatus(
    ...           failure = StatusItem(points = Points(["F"])),
    ...           rightCensored = StatusItem(points = Points(["R"])),
    ...           leftCensored = StatusItem(points = Points(["L"])))).
    ...       setMedianRankEstimation("RRY").
    ...       setMedianRankObtainMethod("BetaFDistribution").
    ...       setStatusConflictTreatment("DERIVATION").
    ...       setEstimationMethod("MRR").
    ...       setDistribution("Weibull").
    ...       setOutProbDensityFunc(True).
    ...       setOutCumDistFunc(True).
    ...       setOutSurvivalFunc(True).
    ...       setOutRegressionPlot(True).
    ...       setOutMedianRankRegPlot(True).
    ...       setComputeGroupComparison(True)
    >>> pdfModel = pdf.fit(data)
    >>> predictions = pdfModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(ParametricDistributionFitting, self).__init__(manager,'com.ibm.spss.ml.survivalanalysis.ParametricDistributionFitting')

    def _create_model(self, java_model):
        return ParametricDistributionFittingModel(None, java_model)


@inherit_doc
class ParametricDistributionFittingModel(Scorer,
                                         HasCommonParamsParams,
                                         HasRegressionParamsParams,
                                         HasEnsembleParamsParams
                                         ):
    """
    Model produced by :class:`ParametricDistributionFitting`.

    ParametricDistributionFitting exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `ParametricDistributionFitting Output Document <../../../../../../output-doc/ParametricDistributionFitting.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(ParametricDistributionFittingModel, self).__init__(manager, 'com.ibm.spss.ml.survivalanalysis.ParametricDistributionFittingModel', java_model)
