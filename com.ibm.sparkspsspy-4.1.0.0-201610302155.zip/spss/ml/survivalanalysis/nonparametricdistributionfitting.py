#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hascoxparams import HasCoxParamsParams
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasgroupfields import HasGroupFieldsParams
from spss.ml.param.hasrecurrent import HasRecurrentParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hasstatusfield import HasStatusFieldParams
from spss.ml.param.hasstratafields import HasStrataFieldsParams
from spss.ml.param.hassurvivaltimefield import HasSurvivalTimeFieldParams
from spss.ml.param.nonparametricdistributionfitting import NonParametricDistributionFittingParams


@inherit_doc
class NonParametricDistributionFitting(AFEstimator,
                                       NonParametricDistributionFittingParams,
                                       HasGroupFieldsParams,
                                       HasStatusFieldParams,
                                       HasStrataFieldsParams,
                                       HasSurvivalTimeFieldParams,
                                       HasRecurrentParams,
                                       HasFreqFieldParams):

    """
    Survival analysis analyzes data where the outcome variable is the time until the occurrence of an event of interest. The distribution of the event times is typically described by a survival function.

    Non-parametric Distribution Fitting (NPDF) provides an estimate of the survival function without making any assumptions concerning the distribution of the data. NPDF includes Kaplan-Meier estimation, life tables, and specialized extension algorithms to support left censored, interval censored, and recurrent event data.

    Example code:

    >>> from spss.ml.param.hasstratafields import HasStrataFieldsParams
    >>> from spss.ml.survivalanalysis.params.definedstatus import DefinedStatus, StatusItem, Points
    >>> from spss.ml.survivalanalysis.nonparametricdistributionfitting import NonParametricDistributionFitting, NonParametricDistributionFittingModel
    >>> npdf = NonParametricDistributionFitting().
    ...   setAlgorithm("KM").
    ...   setBeginField("time").
    ...   setStatusField("status").
    ...   setStrataFields(["treatment"]).
    ...   setGroupFields(["gender"]).
    ...   setUndefinedStatus("INTERVALCENSORED").
    ...   setDefinedStatus(
    ...   DefinedStatus(
    ...     failure = StatusItem(points = Points(["1"])),
    ...     rightCensored = StatusItem(points = Points(["0"]))).
    ...   setOutMeanSurvivalTime(True)
    >>> npdfModel = npdf.fit(df)
    >>> predictions = npdfModel.transform(data)
    """

    def __init__(self, manager=None):
        super(NonParametricDistributionFitting, self).__init__(manager,'com.ibm.spss.ml.survivalanalysis.NonParametricDistributionFitting')

    def _create_model(self, java_model):
        return NonParametricDistributionFittingModel(None, java_model)


@inherit_doc
class NonParametricDistributionFittingModel(Scorer,
                                            HasCommonParamsParams,
                                            HasRegressionParamsParams,
                                            HasCoxParamsParams):
    """
    Model produced by :class:`NonParametricDistributionFitting`.

    NonParametricDistributionFitting exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.

    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `NonParametricDistributionFitting Output Document <../../../../../output-doc/NonParametricDistributionFitting.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(NonParametricDistributionFittingModel, self).__init__(manager, 'com.ibm.spss.ml.survivalanalysis.NonParametricDistributionFittingModel', java_model)
