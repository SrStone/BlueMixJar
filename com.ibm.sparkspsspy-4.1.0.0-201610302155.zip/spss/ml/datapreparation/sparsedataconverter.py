#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFTransformer, ContainerCapability, StatJSONExportable
from spss.ml.param.sparsedataconverter import SparseDataConverterParams


@inherit_doc
class SparseDataConverter(AFTransformer, ContainerCapability, SparseDataConverterParams, StatJSONExportable):
    """
    Sparse Data Convertor (SDC)  converts regular data fields into list fields. Users just need to specify the fields that they want to convert into list fields, then SDC will merge the fields according to their measurement level. It will generate at most three kinds of list fields: continuous list field, categorical list field, and map field.

    Example code:\n
    >>> from spss.ml.datapreparation.sparsedataconverter import SparseDataConverter
    >>> sdc = SparseDataConverter().
    ...     setInputFieldList(["Age", "Sex", "Marriage", "BP", "Cholesterol", "Na", "K", "Drug"])
    >>> predictions = sdc.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(SparseDataConverter, self).__init__(manager,'com.ibm.spss.ml.datapreparation.SparseDataConverter')
