#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFTransformer
from spss.ml.param.mrsampling import MRSamplingParams

@inherit_doc
class MRSampling(AFTransformer, MRSamplingParams):
    """
    The mrsampling function selects a pseudo-random sample of records from a data source at a specified sampling ratio. The size of the
    sample will be approximately the specified proportion of the total number of records subject to an optional maximum. The set of
    records and their total number will vary with random seed. Every record in the data source has the same probability of being selected.

    Example code:

    >>> from spss.ml.datapreparation.sampling.mrsampling import MRSampling
    >>> ms = MRSampling().setDiscard(False).setRandomSeed(123).setSamplingRatio(0.2)
    >>> transform_df = ms.transform(df)

    """

    def __init__(self, manager=None):
        super(MRSampling, self).__init__(manager,
                                         'com.ibm.spss.ml.datapreparation.sampling.MRSampling')