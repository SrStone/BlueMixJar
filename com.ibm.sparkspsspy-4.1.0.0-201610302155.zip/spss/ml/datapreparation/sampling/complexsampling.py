#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc
from spss.ml.param.complexsampling import *
from spss.ml.datapreparation.params.sampling import *
from spss.ml.common.wrapper import AFTransformer


@inherit_doc
class ComplexSampling(AFTransformer, ComplexSamplingParams):
    """
    The complexSampling function selects a pseudo-random sample of records from a data source.

    The complexSampling function performs stratified sampling of incoming data using simple exact
    sampling and simple proportional sampling. The stratifying fields are specified as input and the
    sampling counts or sampling ratio for each of the strata to be sampled must also be provided.
    Optionally, the record counts for each strata may be provided to improve performance.

    Example code:

    >>> from spss.ml.datapreparation.sampling.complexsampling import ComplexSampling
    >>> from spss.ml.datapreparation.params.sampling import RealStrata, Strata, Stratification, StringStrata
    >>> transformer = ComplexSampling().
    ...    setRandomSeed(123444).
    ...    setRepeatable(True).
    ...    setStratification(Stratification(["real_field"], [
    ...       Strata(key = [RealStrata(11.1)], samplingCount = 25),
    ...       Strata(key = [RealStrata(2.4)], samplingCount = 40),
    ...       Strata(key = [RealStrata(12.9)], samplingRatio = 0.5)
    ...     ])).
    ...    setFrequencyField("frequency_field")
    >>> sampled = transformer.transform(unionDF)
    """

    def __init__(self, manager=None):
        super(ComplexSampling, self).__init__(manager, 'com.ibm.spss.ml.datapreparation.sampling.ComplexSampling')
