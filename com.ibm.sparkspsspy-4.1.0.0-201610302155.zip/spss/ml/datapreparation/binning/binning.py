#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc
from pyspark.ml.wrapper import JavaTransformer

from spss.ml.common.wrapper import ContainerCapability
from spss.ml.param.binning import BinningParams


@inherit_doc
class Binning(JavaTransformer, BinningParams, ContainerCapability):
    """
    The function can be used to derive one or more new binned fields and/or to obtain the bin definitions used to determine the bin values.

    Example code:

    >>> from spss.ml.datapreparation.binning.binning import Binning
    >>> from spss.ml.param.binningsettings import *
    >>> binDefinition = BinDefinitions(1, False, True, True, [CutPoint(50.0, False)])
    >>> binRequest = BinRequest("integer_field", "integer_bin", binDefinition, binDefinitionSetting)
    >>> bining = Binning().setBinRequestsParam([binRequest])
    >>> outputDF = bining.transform(inputDF)
    """

    def __init__(self):
        super(Binning, self).__init__()
        self._java_obj = self._new_java_obj('com.ibm.spss.ml.datapreparation.binning.Binning')
