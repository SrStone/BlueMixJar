#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.param.descriptives import DescriptivesParams
from spss.ml.common.params.params import PairsParam
from spss.ml.param.descriptivesselectionstrategy import DescriptivesSelectionStrategyParams
from spss.ml.common.wrapper import Scorer, AFEstimator, StatJSONExportable


@inherit_doc
class Descriptives(AFEstimator, DescriptivesParams, PairsParam):
    """
    Descriptives provides efficient computation of the univariate and bivariate statistics and automatic data preparation features on large scale data. It can be used widely in data profiling, data exploration, and data preparation for subsequent modeling analyses.

    The core statistical features include essential univariate and bivariate statistical summaries, univariate order statistics, metadata information creation from raw data, statistics for visualization of single fields and field pairs, data preparation features, as well as data interestingness score and data quality assessment. It can efficiently support the functionality required for automated data processing, user interactivity and obtaining data insights for single fields or the relationships between the pairs of fields inclusive with specified target.

    Example code:

    >>> from spss.ml.datapreparation.descriptives import Descriptives, DescriptivesModel, DescriptivesSelectionStrategy, DescriptivesSelectionStrategyModel
    >>> from spss.ml.common.wrapper import LocalContainerManager
    >>> de = Descriptives().
    ...   setInputFieldsList(["Field1", "Field2"]).
    ...   setTargetFieldList(["Field3"]).
    ...   setTrimBlanks("TRIM_BOTH")
    >>> deModel = de.fit(df)
    >>> c = deModel.containerSeq()
    >>> PMML = c.entryStringContent("PMML.xml")
    >>> statXML = c.entryStringContent("StatXML.xml")
    >>> cons = deModel.containers()
    >>> containerManager = LocalContainerManager()
    >>> containerManager.exportContainers("key", cons)
    >>> deScore = DescriptivesModel(containerManager)
    >>> deScore.setInputContainerKeys(["key"])
    >>> predictions = deScore.transform(df)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(Descriptives, self).__init__(manager,'com.ibm.spss.ml.datapreparation.Descriptives')

    def _create_model(self, java_model):
        return DescriptivesModel(None, java_model)


@inherit_doc
class DescriptivesModel(Scorer, StatJSONExportable):
    """
    Model produced by :class:`Descriptives`.

    Descriptives exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralStructure.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `Descriptives Output Document <../../../../../output-doc/Descriptives.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(DescriptivesModel, self).__init__(manager, 'com.ibm.spss.ml.datapreparation.DescriptivesModel', java_model)


@inherit_doc
class DescriptivesSelectionStrategy(AFEstimator, DescriptivesSelectionStrategyParams):
    """
    When the number of field pairs is too large (for example, larger than the default of 1,000), SelectionStrategy is used to limit the number of pairs for which bivariate statistics will be computed. The strategy involves 2 steps:

    1. Limit the number of pairs based on the univariate statistics.
    2. Limit the number of pairs based on the core association bivariate statistics.


    Notice that the pair will be always included under the following conditions:

    1. The pair consists of a predictor field and a target field.
    2. The pair of predictors or targets is enforced.
    """

    def __init__(self, manager=None):
        super(DescriptivesSelectionStrategy, self).__init__(manager,'com.ibm.spss.ml.datapreparation.DescriptivesSelectionStrategy')

    def _create_model(self, java_model):
        return DescriptivesSelectionStrategyModel(None, java_model)


@inherit_doc
class DescriptivesSelectionStrategyModel(Scorer):
    """
    Model produced by :class: `Descriptives DescriptivesSelectionStrategy`.

    DescriptivesSelectionStrategy exports outputs:

    * Json file, contains extended model information.

    More details about outputs, please refer to
    `DescriptivesSelectionStrategy Output Document <../../../../../output-doc/DescriptivesSelectionStrategy.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(DescriptivesSelectionStrategyModel, self).__init__(manager, 'com.ibm.spss.ml.datapreparation.DescriptivesSelectionStrategyModel', java_model)

