#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.hascategoricalparams import HasCategoricalParamsParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hasfreqfield import HasFreqFieldParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.linearsupportvectormachine import LinearSupportVectorMachineParams
from spss.ml.param.haspredictioncol import HasPredictionColParams


@inherit_doc
class LinearSupportVectorMachine(AFEstimator, LinearSupportVectorMachineParams, HasTargetFieldParams,
                                 HasInputFieldListParams,
                                 HasFreqFieldParams):
    """
    The Linear Support Vector Machine (LSVM) provides a supervised learning method that
    generates input-output mapping functions from a set of labeled training data.
    The mapping function can be either a classification function or a regression function.
    LSVM is designed to resolve large-scale problems in terms of the number of records and
    the number of variables (parameters). Its feature space is the same as the input
    space of the problem, and it can handle sparse data where the average number of
    non-zero elements in one record is small.

    Example code:

    >>> from spss.ml.classificationandregression.linearsupportvectormachine import LinearSupportVectorMachine
    >>> lsvm = LinearSupportVectorMachine().
    ...     setTargetField("BareNuc").
    ...     setInputFieldList(["Clump", "UnifSize", "UnifShape", "MargAdh", "SingEpiSize", "BlandChrom", "NormNucl", "Mit", "Class"]).
    ...     setPenaltyFunction("L2")
    >>> lsvmModel = lsvm.fit(df)
    >>> predictions = lsvmModel.transform(data)
    >>> predictions.show()
    """

    def __init__(self, manager=None):
        super(LinearSupportVectorMachine, self).__init__(
            manager,
            'com.ibm.spss.ml.classificationandregression.LinearSupportVectorMachine')

    def _create_model(self, java_model):
        return LinearSupportVectorMachineModel(None, java_model)


@inherit_doc
class LinearSupportVectorMachineModel(Scorer,
                                      HasCommonParamsParams,
                                      HasCategoricalParamsParams,
                                      HasRegressionParamsParams,
                                      HasPredictionColParams):
    """
    Model produced by :class:`LinearSupportVectorMachine`.

    LinearSupportVectorMachine exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/TreeModel.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to
    `LinearSupportVectorMachine Output Document <../../../../../../output-doc/LinearSupportVectorMachine.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(LinearSupportVectorMachineModel, self).__init__(
            manager,
            'com.ibm.spss.ml.classificationandregression.LinearSupportVectorMachineModel',
            java_model)
