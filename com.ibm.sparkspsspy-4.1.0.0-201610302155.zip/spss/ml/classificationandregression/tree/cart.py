#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from pyspark.ml.wrapper import JavaEstimator, JavaModel
from spss.ml.param.cart import CARTParams

@inherit_doc
class CART(JavaEstimator, CARTParams):
    """
    """
    def __init__(self):
        super(CART, self).__init__()
        self._java_obj = self._new_java_obj(
                "com.ibm.spss.ml.classificationandregression.tree.cart.CART", self.uid)

    def _create_model(self, java_model):
        return CARTModel(java_model)


class CARTModel(JavaModel):
    """
    """

