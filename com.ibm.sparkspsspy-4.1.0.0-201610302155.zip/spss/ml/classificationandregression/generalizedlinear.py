#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.classificationandregression.params.effect import Effect
from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.generalizedlinear import GeneralizedLinearParams
from spss.ml.param.hastargetfield import HasTargetFieldParams
from spss.ml.param.hasinputfieldlist import HasInputFieldListParams
from spss.ml.param.hascommonparams import HasCommonParamsParams
from spss.ml.param.hascategoricalparams import HasCategoricalParamsParams
from spss.ml.param.hasregressionparams import HasRegressionParamsParams
from spss.ml.param.haspredictioncol import HasPredictionColParams


@inherit_doc
class GeneralizedLinear(AFEstimator, GeneralizedLinearParams, HasTargetFieldParams, HasInputFieldListParams):
    """
    The Generalized Linear Model(GLE) is a commonly used analytical algorithm for different types of data. It covers not only widely used statistical models, such as linear regression for normally distributed targets, logistic models for binary or multinomial targets, and log linear models for count data, but also covers many useful statistical models via its very general model formulation.In addition to building the model, Generalized Linear Model provides other useful features such as variable selection, automatic selection of distribution and link function, and model evaluation statistics. This model has options for regularization, such as LASSO, ridge regression, elastic net, etc., and is also capable of handling very wide data.

    More details about how to choose distribution and link function, please refer to `Distribution and Link Function Combination <http://spss-algo-api.mybluemix.net/doc/output-doc/DistritbutionAndLinkfunc.html>`_.

    Example code 1:\n
    This example shows a GLE setting with specified distribution and link function, specified effects, intercept, conducting ROC curve, printing correlation matrix.
    This scenario builds a model, then scores the model.

    >>> from spss.ml.classificationandregression.generalizedlinear import GeneralizedLinear
    >>> gle1 = GeneralizedLinear().
    ...   setTargetField("Work_experience").
    ...   setInputFieldList(["Beginning_salary", "Sex_of_employee", "Educational_level", "Minority_classification", "Current_salary"]).
    ...   setEffects([
    ...       Effect(fields = ["Beginning_salary"], nestingLevels = [0]),
    ...       Effect(fields = ["Sex_of_employee"], nestingLevels = [0]),
    ...       Effect(fields = ["Educational_level"], nestingLevels = [0]),
    ...       Effect(fields = ["Current_salary"], nestingLevels = [0]),
    ...       Effect(fields = ["Sex_of_employee", "Educational_level"], nestingLevels = [0, 0])]).
    ...   setIntercept(True).
    ...   setDistribution("NORMAL").
    ...   setLinkFunction("LOG").
    ...   setAnalysisType("BOTH").
    ...   setConductRocCurve(True)
    >>> gleModel1 = gle1.fit(data)
    >>> pmml = gleModel1.toPMML()
    >>> statXML = gleModel1.statXML()
    >>> predictions1 = gleModel1.transform(data)
    >>> predictions1.show()


    Example code 2:\n
    This example shows a GLE setting with unspecified distribution and link function, and variable selection using forward stepwise method.
    This scenario uses forward stepwise method to select distribution, link function and effects, then builds model and scores the model.

    >>> from spss.ml.classificationandregression.generalizedlinear import GeneralizedLinear
    >>> gle2 = GeneralizedLinear().
    ...   setTargetField("Work_experience").
    ...   setInputFieldList(["Beginning_salary", "Sex_of_employee", "Educational_level", "Minority_classification", "Current_salary"]).
    ...   setEffects([
    ...       Effect(fields = ["Beginning_salary"], nestingLevels = [0]),
    ...       Effect(fields = ["Sex_of_employee"], nestingLevels = [0]),
    ...       Effect(fields = ["Educational_level"], nestingLevels = [0]),
    ...       Effect(fields = ["Current_salary"], nestingLevels = [0])]).
    ...   setIntercept(True).
    ...   setDistribution("UNKNOWN").
    ...   setLinkFunction("UNKNOWN").
    ...   setAnalysisType("BOTH").
    ...   setUseVariableSelection(True).
    ...   setVariableSelectionMethod("FORWARD_STEPWISE")
    >>> gleModel2 = gle2.fit(data)
    >>> pmml = gleModel2.toPMML()
    >>> statXML = gleModel2.statXML()
    >>> predictions2 = gleModel2.transform(data)
    >>> predictions2.show()


    Example code 3:\n
    This example shows a GLE setting with unspecified distribution, specified link function, and variable selection using LASSO method, with two-way interaction detection and automatic penalty parameter selection.
    This scenario detects two-way interaction for effects, then uses LASSO method to select distribution and effects using automatic penalty parameter selection, then builds model and scores the model.

    >>> import com.ibm.spss.ml.classificationandregression.GeneralizedLinear
    >>> gle3 = GeneralizedLinear().
    ...   setTargetField("Work_experience").
    ...   setInputFieldList(["Beginning_salary", "Sex_of_employee", "Educational_level", "Minority_classification", "Current_salary"]).
    ...   setEffects([
    ...     Effect(fields = ["Beginning_salary"], nestingLevels = [0]),
    ...     Effect(fields = ["Sex_of_employee"], nestingLevels = [0]),
    ...     Effect(fields = ["Educational_level"], nestingLevels = [0]),
    ...     Effect(fields = ["Current_salary"], nestingLevels = [0])]).
    ...   setIntercept(True).
    ...   setDistribution("UNKNOWN").
    ...   setLinkFunction("LOG").
    ...   setAnalysisType("BOTH").
    ...   setDetectTwoWayInteraction(True).
    ...   setUseVariableSelection(True).
    ...   setVariableSelectionMethod("LASSO").
    ...   setUserSpecPenaltyParams(False)
    >>> gleModel3 = gle3.fit(data)
    >>> pmml = gleModel3.toPMML()
    >>> statXML = gleModel3.statXML()
    >>> predictions3 = gleModel3.transform(data)
    >>> predictions3.show()
    """

    def __init__(self, manager=None):
        super(GeneralizedLinear, self).__init__(manager,
                                                'com.ibm.spss.ml.classificationandregression.GeneralizedLinear')

    def _create_model(self, java_model):
        return GeneralizedLinearModel(None, java_model)


@inherit_doc
class GeneralizedLinearModel(Scorer, HasCommonParamsParams, HasCategoricalParamsParams, HasRegressionParamsParams,
                             HasPredictionColParams):
    """
    Model produced by :class:`GeneralizedLinear`.

    GeneralizedLinear exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralRegression.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `GeneralizedLinear Output Document <../../../../../../output-doc/GeneralizedLinear.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(GeneralizedLinearModel, self).__init__(manager,
                                                     'com.ibm.spss.ml.classificationandregression.GeneralizedLinearModel',
                                                     java_model)
