#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFUtility


@inherit_doc
class PMMLMerge(AFUtility):
    """
    A utility for merging PMML with TransformationDictionary produced by :class:`Descriptives`
    or any other system with a PMML containing a model built on the transformed data.

    Example code:

    >>> from spss.ml.utils.pmmlmerge import PMMLMerge
    >>> containerKey = "key"
    >>> containerManager.exportContainers(containerKey, containers)
    >>> merged = PMMLMerge(containerManager).setInputContainerKeys([containerKey]).run
    >>> pmml = merged.containerSeq().entryStringContent("PMML.xml")
    """

    def __init__(self, manager):
        super(PMMLMerge, self).__init__()
        self._java_obj = self._new_java_obj("com.ibm.spss.ml.utils.PMMLMerge", manager._java_instance)
