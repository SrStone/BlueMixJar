#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

# DO NOT MODIFY THIS FILE!
from pyspark.ml.param import Param, Params


class HasStatusFieldParams(Params):
    """
    HasStatusField parameters.
    """

    # a placeholder to make it appear in the generated doc
    definedStatus = Param(Params._dummy(), "definedStatus", """Param for mapping of status variable values to the set of "F", "R", "L", "I". For example: {{{setDefinedStatus( DefinedStatus( rightCensored = StatusItem(points = Points("R")), leftCensored = StatusItem(points = Points("L")), intervalCensored = StatusItem(points = Points("I")) ) ). setUndefinedStatus("FAILURE") }}}""")
    statusField = Param(Params._dummy(), "statusField", """Param for the field name of survival status.If both "beginField" and "endField" are provided then status is computed from their values. Otherwise status is always "F".""")
    statusConflictTreatment = Param(Params._dummy(), "statusConflictTreatment", """Param for choosing whether to fix or skip the record, when status is not consistent with two time field values. Supported methods: - "DISCARDCONFLICTRECORD" - "CONFORMANCE" - "DERIVATION" Default: DISCARDCONFLICTRECORD "DISCARDCONFLICTRECORD" means "skip the conflict record". "CONFORMANCE" means use the status field value. "DERIVATION" means use the "beginTime" and "endTime" compute.""")
    undefinedStatus = Param(Params._dummy(), "undefinedStatus", """Param for specifying the status not listed in definedStatus. Supported methods: - "NONE" - "FAILURE" - "LEFTCENSORED" - "RIGHTCENSORED" - "INTERVALCENSORED" Default: NONE""")
    

    def __init__(self):
        super(HasStatusFieldParams, self).__init__()
        #: param for Param for mapping of status variable values to the set of "F", "R", "L", "I". For example: {{{setDefinedStatus( DefinedStatus( rightCensored = StatusItem(points = Points("R")), leftCensored = StatusItem(points = Points("L")), intervalCensored = StatusItem(points = Points("I")) ) ). setUndefinedStatus("FAILURE") }}}
        self.definedStatus = Param(self, "definedStatus", """Param for mapping of status variable values to the set of "F", "R", "L", "I". For example: {{{setDefinedStatus( DefinedStatus( rightCensored = StatusItem(points = Points("R")), leftCensored = StatusItem(points = Points("L")), intervalCensored = StatusItem(points = Points("I")) ) ). setUndefinedStatus("FAILURE") }}}""")
        #: param for Param for the field name of survival status.If both "beginField" and "endField" are provided then status is computed from their values. Otherwise status is always "F".
        self.statusField = Param(self, "statusField", """Param for the field name of survival status.If both "beginField" and "endField" are provided then status is computed from their values. Otherwise status is always "F".""")
        #: param for Param for choosing whether to fix or skip the record, when status is not consistent with two time field values. Supported methods: - "DISCARDCONFLICTRECORD" - "CONFORMANCE" - "DERIVATION" Default: DISCARDCONFLICTRECORD "DISCARDCONFLICTRECORD" means "skip the conflict record". "CONFORMANCE" means use the status field value. "DERIVATION" means use the "beginTime" and "endTime" compute.
        self.statusConflictTreatment = Param(self, "statusConflictTreatment", """Param for choosing whether to fix or skip the record, when status is not consistent with two time field values. Supported methods: - "DISCARDCONFLICTRECORD" - "CONFORMANCE" - "DERIVATION" Default: DISCARDCONFLICTRECORD "DISCARDCONFLICTRECORD" means "skip the conflict record". "CONFORMANCE" means use the status field value. "DERIVATION" means use the "beginTime" and "endTime" compute.""")
        #: param for Param for specifying the status not listed in definedStatus. Supported methods: - "NONE" - "FAILURE" - "LEFTCENSORED" - "RIGHTCENSORED" - "INTERVALCENSORED" Default: NONE
        self.undefinedStatus = Param(self, "undefinedStatus", """Param for specifying the status not listed in definedStatus. Supported methods: - "NONE" - "FAILURE" - "LEFTCENSORED" - "RIGHTCENSORED" - "INTERVALCENSORED" Default: NONE""")
        
    def setDefinedStatus(self, value):
        """
        Sets the value of :py:attr:`definedStatus`.
        """
        self._paramMap[self.definedStatus] = value.value()
        return self

    def getDefinedStatus(self):
        """
        Gets the value of definedStatus or its default value.
        """
        return self.getOrDefault(self.definedStatus)

    def setStatusField(self, value):
        """
        Sets the value of :py:attr:`statusField`.
        """
        self._paramMap[self.statusField] = value
        return self

    def getStatusField(self):
        """
        Gets the value of statusField or its default value.
        """
        return self.getOrDefault(self.statusField)

    def setStatusConflictTreatment(self, value):
        """
        Sets the value of :py:attr:`statusConflictTreatment`.
        """
        self._paramMap[self.statusConflictTreatment] = value
        return self

    def getStatusConflictTreatment(self):
        """
        Gets the value of statusConflictTreatment or its default value.
        """
        return self.getOrDefault(self.statusConflictTreatment)

    def setUndefinedStatus(self, value):
        """
        Sets the value of :py:attr:`undefinedStatus`.
        """
        self._paramMap[self.undefinedStatus] = value
        return self

    def getUndefinedStatus(self):
        """
        Gets the value of undefinedStatus or its default value.
        """
        return self.getOrDefault(self.undefinedStatus)
