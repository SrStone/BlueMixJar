#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from spss.ml.common.wrapper import SPSSJavaWrapper

import sys
if sys.version > '3':
    long = int


class BinRequest(object):
    def __init__(self, inField, outField, binDefinitions = None, settings = None):
        self._inField = inField
        self._outField = outField
        
        if binDefinitions is None:
            self._binDefinitions = SPSSJavaWrapper.scalaNone()
        else:
            self._binDefinitions = SPSSJavaWrapper.scalaSome(binDefinitions.value())
        
        if settings is None:
            self._settings = SPSSJavaWrapper.scalaNone()
        else:
            self._settings = SPSSJavaWrapper.scalaSome(settings.value())   

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.BinRequest', self._inField, self._outField, self._binDefinitions, self._settings)


class CutPoint(object):
    def __init__(self, cut, belongsRight):
        self._cut = cut
        self._belongsRight = belongsRight     

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.CutPoint', self._cut, self._belongsRight)


class BinDefinitions(object):
    def __init__(self, startBin, descending, lowerUnbounded, upperUnbounded, cutPoints):
        self._startBin = int(startBin)
        self._descending = descending
        self._lowerUnbounded = lowerUnbounded
        self._upperUnbounded = upperUnbounded
        li = []
        for i in cutPoints:
            li.append(i.value())
        self._cutPoints = SPSSJavaWrapper.scalaList(li)        

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.BinDefinitions', self._startBin, self._descending, self._lowerUnbounded, self._upperUnbounded, self._cutPoints)


class TileBinningSettings(object):
    def __init__(self, tiles, descending):
        self._tiles = int(tiles)
        self._descending = descending     

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.TileBinningSettings', self._tiles, self._descending)


class FixedWidthBinningSettings(object):
    def __init__(self, isEqualWidth, size):
        self._isEqualWidth = isEqualWidth
        self._size = int(size)     

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.FixedWidthBinningSettings', self._isEqualWidth, self._size)


class MeanBinningSettings(object):
    def __init__(self, standardDeviations):
        self._standardDeviations = int(standardDeviations)

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.MeanBinningSettings', self._standardDeviations)


class RectangularBinningSettings(object):
    def __init__(self, simpleBinDefinition):
        self._simpleBinDefinition = simpleBinDefinition.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.RectangularBinningSettings', self._simpleBinDefinition)


class SimpleBinDefinition(object):
    def __init__(self, count, width, start, end):
        self._count = long(count)
        self._width = float(width)
        self._start = float(start)
        self._end = float(end)

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.SimpleBinDefinition', self._count, self._width, self._start, self._end)


class HexBinningSetting(object):
    def __init__(self, outField, inField, binCount, binStart, binEnd, binWidth):
        self._outField = outField
        self._inField = inField
        self._binCount = int(binCount)
        self._binStart = float(binStart)
        self._binEnd = float(binEnd)
        self._binWidth = float(binWidth)
        self._java_object = self.value()            

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.datapreparation.binning.HexBinningSetting', self._outField, 
                                             self._inField,
                                             self._binCount,
                                             self._binStart,
                                             self._binEnd,
                                             self._binWidth)

