#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, IdentityScorer
from spss.ml.param.clustermodelevaluation import ClusterModelEvaluationParams


@inherit_doc
class ClusterModelEvaluation(AFEstimator, ClusterModelEvaluationParams):
    """
    Cluster model evaluation (CME) aims to interpret cluster models and discover useful insights based on various evaluation measures.

    Example code:

    >>> from spss.ml.clustering.clustermodelevaluation import ClusterModelEvaluation
    >>> cme = ClusterModelEvaluation(localContainer).
    ...       setInputContainerKeys(["k"]).
    ...       setEvaluationFieldList(["Na"]).
    ...       setNumBins(8).
    ...       setNumExtEvalCats(8).
    ...       setMaxNumImportantFields(3).
    ...       setSigLevel(0.9).
    ...       setFMeasureBeta(1.0)
    >>> cmeModel = cme.fit(data)
    >>> scored = cmeModel.transform(data)

    """
    def __init__(self, manager=None):
        super(ClusterModelEvaluation, self).__init__(manager, 'com.ibm.spss.ml.clustering.ClusterModelEvaluation')

    def _create_model(self, java_model):
        return ClusterModelEvaluationModel(None, java_model)


@inherit_doc
class ClusterModelEvaluationModel(IdentityScorer):
    """
      Model produced by :class:`ClusterModelEvaluation`.

      ClusterModelEvaluation exports outputs:

      * StatXML file, contains model information.

      More details about outputs, please refer to
      `ClusterModelEvaluation Output Document <../../../../../output-doc/ClusterModelEvaluation.html>`_.
      """

    def __init__(self, manager, java_model=None):
        super(ClusterModelEvaluationModel, self).__init__(manager,
                                                          'com.ibm.spss.ml.clustering.ClusterModelEvaluationModel',
                                                          java_model)
