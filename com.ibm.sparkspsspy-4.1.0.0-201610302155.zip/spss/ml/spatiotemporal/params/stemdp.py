#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from spss.ml.common.wrapper import SPSSJavaWrapper


class RegularData(object):
    def __init__(self, dataStream=None, areaField=None, targetField=None, coordinatesFieldList=None, geoKeyList=None,
                 timeField=None, inputFieldList=None, cyclicFieldList=None):

        if dataStream is None:
            self._dataStream = SPSSJavaWrapper.scalaNone()
        else:
            self._dataStream = SPSSJavaWrapper.scalaSome(dataStream)

        if areaField is None:
            self._areaField = SPSSJavaWrapper.scalaNone()
        else:
            self._areaField = SPSSJavaWrapper.scalaSome(areaField)

        if targetField is None:
            self._targetField = SPSSJavaWrapper.scalaNone()
        else:
            self._targetField = SPSSJavaWrapper.scalaSome(targetField)

        if coordinatesFieldList is None:
            self._coordinatesFieldList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in coordinatesFieldList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._coordinatesFieldList = SPSSJavaWrapper.scalaSome(lo_list)

        if geoKeyList is None:
            self._geoKeyList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in geoKeyList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._geoKeyList = SPSSJavaWrapper.scalaSome(lo_list)

        if timeField is None:
            self._timeField = SPSSJavaWrapper.scalaNone()
        else:
            self._timeField = SPSSJavaWrapper.scalaSome(timeField)

        if inputFieldList is None:
            self._inputFieldList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in inputFieldList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._inputFieldList = SPSSJavaWrapper.scalaSome(lo_list)

        if cyclicFieldList is None:
            self._cyclicFieldList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in cyclicFieldList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._cyclicFieldList = SPSSJavaWrapper.scalaSome(lo_list)

        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.RegularData', self._dataStream,
                                             self._areaField, self._targetField, self._coordinatesFieldList,
                                             self._geoKeyList, self._timeField, self._inputFieldList,
                                             self._cyclicFieldList)


class NewFields(object):
    def __init__(self, targetField=None, timeIndexField=None, areaField=None, coordinatesFieldList=None):

        if targetField is None:
            self._targetField = SPSSJavaWrapper.scalaNone()
        else:
            self._targetField = SPSSJavaWrapper.scalaSome(targetField)

        if timeIndexField is None:
            self._timeIndexField = SPSSJavaWrapper.scalaNone()
        else:
            self._timeIndexField = SPSSJavaWrapper.scalaSome(timeIndexField)

        if areaField is None:
            self._areaField = SPSSJavaWrapper.scalaNone()
        else:
            self._areaField = SPSSJavaWrapper.scalaSome(areaField)

        if coordinatesFieldList is None:
            self._coordinatesFieldList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in coordinatesFieldList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._coordinatesFieldList = SPSSJavaWrapper.scalaSome(lo_list)

        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.NewFields', self._targetField,
                                             self._timeIndexField, self._areaField, self._coordinatesFieldList)


class PointOccurrence(object):
    def __init__(self, dataStream=None, coordinatesField=None, timeField=None, cyclicFieldList=None,
                 intensityMeasure="KDE", bandWidth=-1.0, bandWidthPercent=3.3333333333333335, bandWidthUnit="METER",
                 frequencyWeightField=None):

        if dataStream is None:
            self._dataStream = SPSSJavaWrapper.scalaNone()
        else:
            self._dataStream = SPSSJavaWrapper.scalaSome(dataStream)

        if coordinatesField is None:
            self._coordinatesField = SPSSJavaWrapper.scalaNone()
        else:
            self._coordinatesField = SPSSJavaWrapper.scalaSome(coordinatesField)

        if timeField is None:
            self._timeField = SPSSJavaWrapper.scalaNone()
        else:
            self._timeField = SPSSJavaWrapper.scalaSome(timeField)

        if cyclicFieldList is None:
            self._cyclicFieldList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in cyclicFieldList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._cyclicFieldList = SPSSJavaWrapper.scalaSome(lo_list)

        self._intensityMeasure = SPSSJavaWrapper.scalaSome(intensityMeasure)
        self._bandWidth = SPSSJavaWrapper.scalaSome(bandWidth)
        self._bandWidthPercent = SPSSJavaWrapper.scalaSome(bandWidthPercent)
        self._bandWidthUnit = SPSSJavaWrapper.scalaSome(bandWidthUnit)

        if frequencyWeightField is None:
            self._frequencyWeightField = SPSSJavaWrapper.scalaNone()
        else:
            self._frequencyWeightField = SPSSJavaWrapper.scalaSome(frequencyWeightField)

        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.PointOccurrence', self._dataStream,
                                             self._coordinatesField, self._timeField, self._cyclicFieldList,
                                             self._intensityMeasure, self._bandWidth, self._bandWidthPercent,
                                             self._bandWidthUnit, self._frequencyWeightField)


class LayoutData(object):
    def __init__(self, dataStream=None, geoKeyList=None, polygonField=None, exportedGeoID=None, centroidField=None,
                 areaField=None):

        if dataStream is None:
            self._dataStream = SPSSJavaWrapper.scalaNone()
        else:
            self._dataStream = SPSSJavaWrapper.scalaSome(dataStream)

        if geoKeyList is None:
            self._geoKeyList = SPSSJavaWrapper.scalaNone()
        else:
            lo = []
            for i in geoKeyList:
                lo.append(i)
            lo_list = SPSSJavaWrapper.scalaList(lo)
            self._geoKeyList = SPSSJavaWrapper.scalaSome(lo_list)

        if polygonField is None:
            self._polygonField = SPSSJavaWrapper.scalaNone()
        else:
            self._polygonField = SPSSJavaWrapper.scalaSome(polygonField)

        if exportedGeoID is None:
            self._exportedGeoID = SPSSJavaWrapper.scalaNone()
        else:
            self._exportedGeoID = SPSSJavaWrapper.scalaSome(exportedGeoID)

        if centroidField is None:
            self._centroidFieldField = SPSSJavaWrapper.scalaNone()
        else:
            self._centroidFieldField = SPSSJavaWrapper.scalaSome(centroidField)

        if areaField is None:
            self._areaField = SPSSJavaWrapper.scalaNone()
        else:
            self._areaField = SPSSJavaWrapper.scalaSome(areaField)

        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.LayoutData', self._dataStream,
                                             self._geoKeyList, self._polygonField, self._centroidFieldField,
                                             self._areaField)


class SameEncoding(object):
    def __init__(self, value):
        self._value = SPSSJavaWrapper.scalaListList(value)
        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.SameEncoding', self._value)


class PairsToExclude(object):
    def __init__(self, params):
        lf = ((k, v) for k, v in params.items())
        li = []
        for i in lf:
            li.append(SPSSJavaWrapper.scalaTuple2(i))
        self._params = SPSSJavaWrapper.scalaList(li)
        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.PairsToExclude', self._params)


class EventCoordinates(object):
    def __init__(self, eventLocX, eventLocY):
        self._eventLocX = eventLocX
        self._eventLocY = eventLocY
        self._java_object = self.value()

    def value(self):
        return SPSSJavaWrapper._new_java_obj('com.ibm.spss.ml.spatiotemporal.params.EventCoordinates', self._eventLocX,
                                             self._eventLocY)
