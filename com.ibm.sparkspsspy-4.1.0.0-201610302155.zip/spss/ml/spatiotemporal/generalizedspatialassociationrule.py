#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, Scorer
from spss.ml.param.generalizedspatialassociationrule import GeneralizedSpatialAssociationRuleParams
from spss.ml.param.hasassocparams import HasAssocParamsParams
from spss.ml.param.hascommonparams import HasCommonParamsParams


@inherit_doc
class GeneralizedSpatialAssociationRule(AFEstimator, GeneralizedSpatialAssociationRuleParams):
    """
    Generalized Spatial Association Rule (GSAR) is an exploratory tool applying to spatial and non-spatial data to find association rules describing the frequent patterns of relationships between the event data sources and the geo-context data sources. Apriori, the traditional association rule mining method, is used to identify frequent itemsets then generate rules from the frequent itemsets table. It can be applied to data without spatial information as well.

    Example code:\n
        >>> from spss.ml.spatiotemporal.generalizedspatialassociationrule import GeneralizedSpatialAssociationRule
        >>> from spss.ml.spatiotemporal.params.stemdp import SameEncoding, PairsToExclude
        >>> estimator = GeneralizedSpatialAssociationRule().
        ...		setMinSupport(0.4).
        ...		setMinConfidence(0.8).
        ...		setMaxLength(5).
        ...		setMinAntSupport(2.0E-7).
        ...		setMaxNAnt(5).
        ...		setMaxNCons(3).
        ...		setMinLift(1.0).
        ...		setHighestSupport4Item(1.0).
        ...		setHasRuleWithEmptyAntecedent(True).
        ...		setItemCreationFromFlag("ONLY_TRUE").
        ...		setBothFields(["OFFGEN", "DAY_", "road_closeTo_Name_1", "road_closeTo_Name_2", "road_closeTo_Name_1_gen_1", "road_closeTo_Name_2_gen_1"]).
        ...		setMaxNRules(50).
        ...		setSameEncoding(SameEncoding([
        ...		  ["road_closeTo_Name_1", "road_closeTo_Name_2"],
        ...		  ["road_closeTo_Name_1_gen_1", "road_closeTo_Name_2_gen_1"])).
        ...		setPairsToExclude(PairsToExclude([
        ...		  ["road_closeTo_Name_1", "road_closeTo_Name_1_gen_1"],
        ...		  ["road_closeTo_Name_2", "road_closeTo_Name_2_gen_1"]]))
        >>> model = estimator.fit(data)
        >>> outputData = model.transform(data)
        >>> outputData.show()
    """

    def __init__(self, manager=None):
        super(GeneralizedSpatialAssociationRule, self).__init__(manager,
                                                                'com.ibm.spss.ml.spatiotemporal.GeneralizedSpatialAssociationRule')

    def _create_model(self, java_model):
        return GeneralizedSpatialAssociationRuleModel(None, java_model)


@inherit_doc
class GeneralizedSpatialAssociationRuleModel(Scorer,
                                             HasCommonParamsParams,
                                             HasAssocParamsParams):
    """
    Model produced by :class:`GeneralizedSpatialAssociationRule`.

    GeneralizedSpatialAssociationRule exports two outputs:

    * PMML file, contains model that follows `DMG PMML Standard <http://dmg.org/pmml/v4-2-1/GeneralRegression.html>`_.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `GeneralizedSpatialAssociationRule Output Document <../../../../../../output-doc/GeneralizedSpatialAssociationRule.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(GeneralizedSpatialAssociationRuleModel, self).__init__(manager,
                                                                     'com.ibm.spss.ml.spatiotemporal.GeneralizedSpatialAssociationRuleModel',
                                                                     java_model)
