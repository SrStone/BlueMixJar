#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, DirectorScorer
from spss.ml.param.spatiotemporalpointprocessmodeling import SpatioTemporalPointProcessModelingParams, SpatioTemporalPointProcessModelParams


@inherit_doc
class SpatioTemporalPointProcessModeling(AFEstimator, SpatioTemporalPointProcessModelingParams):
    """
    Spatio-temporal Point Processes Modeling (PPM) is a modeling tool that applies to transformed regular data, after aggregating irregular point process data intoregular time intervals and well defined spatial areas, to build parametric intensity function models and issue a count prediction at any location for future time. Furthermore, the model includes external predictors, so model-based what-if analysiscan be performed.

    Example code:\n
    >>> from spss.ml.spatiotemporal.spatiotemporalpointprocessmodeling import SpatioTemporalPointProcessModeling
    >>>
    >>> stpPM = SpatioTemporalPointProcessModeling().
    ...		setTargetField("demand").
    ...		setInputFieldList(["age"]).
    ...		setLocationFieldList(["longitude", "latitude"]).
    ...		setTimeIndexField("year").
    ...		setIntercept(True)
    >>> stpModel = stpPM.fit(df)
    >>> scored = stpModel.transform(scoreDF)
    >>> scored.show
    """

    def __init__(self, manager=None):
        super(SpatioTemporalPointProcessModeling, self).__init__(manager,
                                                    'com.ibm.spss.ml.spatiotemporal.SpatioTemporalPointProcessModeling')

    def _create_model(self, java_model):
        return SpatioTemporalPointProcessModel(None, java_model)


@inherit_doc
class SpatioTemporalPointProcessModel(DirectorScorer, SpatioTemporalPointProcessModelParams):
    """
    Model produced by :class:`SpatioTemporalPointProcessModeling`.

    SpatioTemporalPointProcessModeling exports two outputs:

    * PMML file, contains model information.
    * StatXML file, contains extended model information.

    More details about outputs, please refer to `SpatioTemporalPointProcess Output Document <../../../../../../output-doc/SpatioTemporalPointProcess.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(SpatioTemporalPointProcessModel, self).__init__(manager,
                                                         'com.ibm.spss.ml.spatiotemporal.SpatioTemporalPointProcessModel',
                                                         java_model)
