#
# IBM Confidential
#
# OCO Source Materials
#
# NextGen Workbench
#
# (c) Copyright IBM Corp. 2016
#
# The source code for this program is not published or otherwise
# divested of its trade secrets, irrespective of what has been
# deposited with the U.S. Copyright Office.
#

from pyspark.mllib.common import inherit_doc

from spss.ml.common.wrapper import AFEstimator, IdentityScorer
from spss.ml.param.spatiotemporalcluster import SpatioTemporalClusterParams


@inherit_doc
class SpatioTemporalCluster(AFEstimator, SpatioTemporalClusterParams):
    """
   Spatial-temporal clustering (STC) is an exploratory tool for spatio-temporal data with a fixed set of spatial locations (either point locations or center points of areas on a lattice) and a set of time points. STC groups the spatial locations into a few clusters based on similarity in the temporal patterns and similarity in spatial proximity. It is applied to a projected space of polynomials, rather than to the original data space, so differing numbers of time points for each location can be accommodated, and design/time points may be misaligned. Furthermore, it is applicable to one field at a time, not multiple fields. Unlike regular clustering, no scoring/prediction is generated in STC.

   Example code:

   >>> from spss.ml.spatiotemporal.spatiotemporalcluster import SpatioTemporalCluster
   >>> stc = SpatioTemporalCluster().
   ...       setTargetField("target").
   ...       setTimeField(["time"]).
   ...       setLocationFieldList(["coord_x", "coord_y"]).
   ...       setLocationLabel("").
   ...       setAutoAdjustTheta(False).
   ...       setRandomSeed(18977)
   >>>  stc_model = stc.fit(df)
   """
    def __init__(self, manager=None):
        super(SpatioTemporalCluster, self).__init__(manager,
                                                    'com.ibm.spss.ml.spatiotemporal.SpatioTemporalCluster')

    def _create_model(self, java_model):
        return SpatioTemporalClusterModel(None, java_model)


@inherit_doc
class SpatioTemporalClusterModel(IdentityScorer):

    """
       Model produced by :class:`SpatioTemporalCluster`.

       SpatioTemporalCluster exports two outputs:

       * StatXML.xml file, contain model information.
       * JSON file, contain detail of each model.

       More details about outputs, please refer to
       `SpatioTemporalCluster Output Document <../../../../../output-doc/SpatioTemporalCluster.html>`_.
    """

    def __init__(self, manager, java_model=None):
        super(SpatioTemporalClusterModel, self).__init__(manager,
                                                         'com.ibm.spss.ml.spatiotemporal.SpatioTemporalCluster',
                                                         java_model)
